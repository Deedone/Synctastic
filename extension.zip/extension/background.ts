console.log("TEST PLUGIN")


chrome.runtime.onMessage.addListener(onMessage);
let curTab:number = -1;
let curTabName:string = "";
let vidStatus = "unknown";
let netstatus = "offline"
let watchdog = -1;
let ts = 0;
let host = 0;
let ws:WebSocket;


function setupWs(addr:string){
    ws = new WebSocket(addr);
    ws.onmessage = onWsMessage
}

function setActive(tab:chrome.tabs.Tab){
    chrome.runtime.sendMessage({type:"view", cmd:"chtab", data:tab.title})
    if (tab.id){
        curTab = tab.id;
    }
    if (tab.title){
        curTabName = tab.title;
    }
    vidStatus = "pause";
    ts = 0;

    updateView();
    chrome.tabs.sendMessage(curTab, makeVidCmd("activate", 0))
}

function setInactive(tabId:number){
    chrome.runtime.sendMessage({type:"view", cmd:"chtab", data:-1})
    chrome.tabs.sendMessage(tabId, makeVidCmd("activate", ts))
}
function updateView(){
    chrome.runtime.sendMessage({type:"view", cmd:"update",data:{
                status:vidStatus,
                timestamp:ts,
                tab:curTabName,
                netstatus:netstatus
    }})
}

function onWsMessage(msg:any){
    netstatus = "Online"
    console.log(msg.data);
    if (watchdog > -1){
        clearTimeout(watchdog)
    }
    watchdog = setTimeout(() => {
        netstatus = "Offline";
    }, 11000)

    let data = JSON.parse(msg.data)

    switch (data.cmd){
        case "ping":
            ws.send(JSON.stringify({Cmd:"pong"}))

        default:
            sendVidCmd(makeVidCmd(data.cmd, data.timestamp))

    }

    updateView();
}

function makeVidCmd(cmd:string, timestamp:number){
    return {cmd:cmd, timestamp:timestamp};
}

function sendVidCmd(cmd:any){
            chrome.tabs.sendMessage(curTab, cmd)
}

function onMessage(msg:any, sender:any){
    console.log(msg); 

    if (msg.type == "control") {
        if (msg.cmd == "init") {
            chrome.tabs.query({active:true, currentWindow:true}, (tabs) => {
                if (!tabs){
                    return;
                }
                let tab = tabs[0];
                if (curTab != -1){
                    setInactive(curTab);
                }
                setActive(tab);
                setupWs("wss://synctastic.herokuapp.com/")
            });
        }
        if (msg.cmd == "fetch"){
           updateView();
        }

        if (msg.cmd == "video"){
            sendVidCmd(makeVidCmd(msg.data, ts));
        }
        if (msg.cmd == "net"){
            if(msg.data == "beHost"){
                host = 1;
                ws.send(JSON.stringify({Cmd:"setHost", IntArg:1}));
            }
        }
    }
    if (msg.type == "video"){
        if (msg.cmd == "pause" || msg.cmd == "play"){
          vidStatus = msg.cmd;
        }else if(vidStatus == "unknown"){
          vidStatus = "play";
        }
        ts = msg.ts;
        if (host){
            ws.send(JSON.stringify({Cmd:"broadcast", StrArg:JSON.stringify(makeVidCmd(msg.cmd, msg.ts))}))
        }
        updateView();
    }



}