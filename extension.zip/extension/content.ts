console.log("CONTENT");


chrome.runtime.onMessage.addListener(msg => {
        if (msg.cmd == "activate"){
            init();
            active = 1;
        }
        if (msg.cmd == "deactivate"){
            active = 0;
        }
});

let active = 0;

function init(){
    let vid:HTMLVideoElement|null = findVideo();
    if (!vid){
        return;
    }

    attachEvents(vid);

    chrome.runtime.onMessage.addListener(msg => {
        if (!vid){
            console.log("Error video became null")
            return;
        }
            if(msg.cmd == "pause"){
                vid.pause();
                vid.currentTime = msg.timestamp;
            }else if (msg.cmd == "play"){
                vid.play();
                vid.currentTime = msg.timestamp;

            }
            if (Math.abs(vid.currentTime - msg.timestamp) > 0.5){
                vid.currentTime = msg.timestamp + 0.1;
            }
    })
}

function attachEvents(vid: HTMLVideoElement){

    vid.addEventListener("play", onEvent);
    vid.addEventListener("pause", onEvent);
    vid.addEventListener("timeupdate", onEvent);
}

function onEvent(e:any){
    if (!active){
        return;
    }
    console.log(e.type, e.target.currentTime);
    console.log(e);

    let msg = {type:"video",cmd:e.type, ts:e.target.currentTime};
    chrome.runtime.sendMessage(msg);
}

function findVideo() {
    let vids = document.querySelectorAll("video");
    console.log(vids)

    if(vids.length > 0){
        return vids[0]
    }
    return null;
}